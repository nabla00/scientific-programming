def train():
    return "trained"
